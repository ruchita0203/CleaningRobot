﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CleaningRobot.Common.Constant;

namespace CleaningRobot.Model
{
    public class Element
    {
        public int X { get; set; }
        public int Y { get; set; }

        public int Height { get; set; } = 4;
        public int Width { get; set; } = 4;
        public ElementType Type { get; set; } = ElementType.Path;

    }

   
}
