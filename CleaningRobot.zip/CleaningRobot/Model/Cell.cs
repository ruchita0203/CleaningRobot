﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleaningRobot.Model
{
    public class Cell 
    {
        #region Properties

        public double X { get; set; }
        public double Y { get; set; }

        public bool IsClean { get; set; } = false;
        #endregion

    }
}
