﻿using CleaningRobot.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using static CleaningRobot.Common.Constant;

namespace CleaningRobot.View
{
    public class DrawingCanvas : Canvas
    {
        #region Variables
        Rectangle robot;
        Path path;
        PathGeometry pathGeometry;
        PathFigure pathFigure;
        #endregion

        #region Constructor
        public DrawingCanvas()
        {
            robot = new Rectangle();
            path = new Path
            {
                Stroke = Brushes.Blue,
                StrokeThickness = 2
            };

            // Create a PathGeometry and add it to the Path
            pathGeometry = new PathGeometry();
            path.Data = pathGeometry;

            // Create a PathFigure and add it to the PathGeometry
            pathFigure = new PathFigure();
            pathGeometry.Figures.Add(pathFigure);        

        }
        #endregion

        #region Dependency Properties
        public ObservableCollection<Element> Elements
        {
            get { return (ObservableCollection<Element>)GetValue(AnnotationsProperty); }
            set { SetValue(AnnotationsProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Annotations.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty AnnotationsProperty =
            DependencyProperty.Register("Elements", typeof(ObservableCollection<Element>), typeof(DrawingCanvas), new PropertyMetadata(null, OnElementsChanged));



        #endregion

        #region Events
        private static void OnElementsChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        { 
            var canvas = d as DrawingCanvas;
            if (e.OldValue != null && canvas != null)
            {
                ((ObservableCollection<Element>)e.OldValue).CollectionChanged -= canvas.DrawingCanvas_CollectionChanged;
            }
            if (e.NewValue != null && canvas != null)
            {
                ((ObservableCollection<Element>)e.NewValue).CollectionChanged += canvas.DrawingCanvas_CollectionChanged;
            }
        }       

       

        /// <summary>
        /// Get colloction changed event when elements are added into elements list to draw path and robot on UI
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DrawingCanvas_CollectionChanged(object? sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                if (e.NewItems != null)
                {
                    var collection = sender as ObservableCollection<Element>;
                    if (e.NewItems.Count > 0 && collection != null)
                    {
                        var lastItem = collection.LastOrDefault();
                        if (lastItem != null)
                        {
                            if (lastItem.Type == ElementType.Robot)
                            {                              
                                robot.Fill = new SolidColorBrush(Colors.Red);
                                robot.Height = 5;
                                robot.Width = 5;
                                Canvas.SetZIndex(robot, 10);
                                InitializePath();
                                Children.Add(robot);
                                Canvas.SetTop(robot, lastItem.Y);
                                Canvas.SetLeft(robot, lastItem.X);
                            }
                            else
                            {
                                if (robot != null)
                                {
                                    Canvas.SetTop(robot, lastItem.Y);
                                    Canvas.SetLeft(robot, lastItem.X);
                                }
                                if (lastItem.Type == ElementType.Path)
                                {
                                    AddPointToPath(lastItem.X, lastItem.Y);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception )
            {

            }
            finally
            {
                System.GC.Collect();
                System.GC.WaitForPendingFinalizers();
            }
           
        }

        #endregion

        #region Methods

        /// <summary>
        /// To add points into path where robot clean
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        private void AddPointToPath(double x, double y)
        {
            try
            {
                pathFigure.Segments.Add(new LineSegment(new Point(x, y), true));
                path.InvalidateArrange();
                path.InvalidateMeasure();
            }
            catch (Exception )
            {
               
            }           
        }

        /// <summary>
        /// Tp initialize path when robot start to clean
        /// </summary>
        private void InitializePath()
        {
            Children.Add(path);
        }
        #endregion


    }
}
