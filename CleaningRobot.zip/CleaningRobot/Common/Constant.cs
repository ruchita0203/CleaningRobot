﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleaningRobot.Common
{
    public class Constant
    {
        public enum Direction
        {
            East,
            North,
            South,
            West
        }

        public enum Speed
        {
            Fast = 1,
            Moderate = 10000,
            Slow = 50000,            
        }

        public enum ElementType
        {
            Robot,
            Path,
            ReturnPath
        }
    }
}
