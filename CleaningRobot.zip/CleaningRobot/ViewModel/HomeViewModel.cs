﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleaningRobot.ViewModel
{
    public class HomeViewModel : BaseViewModel
    {
        public HomeViewModel()
        {
            currentContentViewModel = new RoomViewModel();
        }


        #region Properties
        private BaseViewModel currentContentViewModel;

        public BaseViewModel CurrentContentViewModel
        {
            get => currentContentViewModel;
            private set => SetProperty(ref currentContentViewModel, value);

        }
        #endregion 
    }
}
