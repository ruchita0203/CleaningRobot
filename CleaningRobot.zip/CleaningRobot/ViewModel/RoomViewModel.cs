﻿using CleaningRobot.Model;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using static CleaningRobot.Common.Constant;

namespace CleaningRobot.ViewModel
{
    public class RoomViewModel : BaseViewModel
    {

        #region Variables
        bool _isReturning = false;
        bool _isCleaningRun = false;
        #endregion

        #region Constructor
        public RoomViewModel()
        {
            CleanCommand = new RelayCommand(Clean,CanClean);
            Initialize();
        }
        #endregion

        #region Properties
        public double Height { get; set; }
        public double Width { get; set; }

        public Direction CurrentDirection { get; set; }
        public Cell CurrentCell { get; set; } = new Cell() { X = 0, Y = 0 };         

        public List<Cell> Cells { get; set; } = new List<Cell>();

        ObservableCollection<Element> elements = new ObservableCollection<Element>();
        public ObservableCollection<Element> Elements
        {
            get => elements;
            set
            {
                SetProperty(ref elements, value);
            }
        }

        public ICommand CleanCommand { get; }


        #endregion

        #region Methods

        /// <summary>
        /// To Initialize properties
        /// </summary>
        public void Initialize()
        {
            Height = 100;
            Width = 100;
            CurrentDirection = Direction.East;
            Elements.Clear();
            //Set current location on left top side corner
            CurrentCell = new Cell() { X = 0, Y = 0 };         
            GetCells();
        }


        /// <summary>
        /// Define all cells of room
        /// </summary>
        public void GetCells()
        {
            Cells.Clear();
            Cell tempCell;
            for (int i = 0; i <= Height; i++)
            {
                for (int j = 0; j <= Width; j++)
                {
                    tempCell = new Cell();
                    tempCell.X = j;
                    tempCell.Y = i;
                    Cells.Add(tempCell);
                }
            }
        }

        /// <summary>
        /// Place robot on its initial position 
        /// </summary>
        void PlaceRobot()
        {
            try
            {
                Element robot = new Element() { X = 0, Y = 0, Height = 2, Width = 2, Type = ElementType.Robot };
                Elements.Add(robot);
            }
            catch (Exception )
            {

            }
        }

        /// <summary>
        /// Apply clean procedure 
        /// </summary>
        private void Clean()
        {
            try
            {
                 _isCleaningRun = true;
                PlaceRobot();
                DrawPath(CurrentCell);
                DispatcherTimer timer = new DispatcherTimer();
                timer.Tick += new EventHandler(timer_Tick);

                timer.Interval = new TimeSpan((int)Speed.Fast);
                timer.Start();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private bool CanClean()
        {
            return !_isCleaningRun;
        }

        /// <summary>
        /// Here we assume direction on east side and did code accordingly 
        /// We need to add more logic to support north and south direction 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer_Tick(object? sender, EventArgs e)
        {
            try
            {
               var uncleanCell = Cells.Where(i => i.IsClean == false).ToList();

                if (uncleanCell.Count > 0)
                {
                    if (CurrentDirection == Direction.East)
                    {
                        CurrentCell.X += 1;
                      
                        if (CurrentCell.X > Width)
                        {
                            CurrentDirection = Direction.West;
                            CurrentCell.Y += 1;
                        }
                    }
                    else if (CurrentDirection == Direction.West)
                    {
                        CurrentCell.X -= 1;
                        if (CurrentCell.X < 0)
                        {
                            CurrentDirection = Direction.East;
                            CurrentCell.Y += 1;
                        }
                    }

                    DrawPath(CurrentCell);
                }
                else if(CurrentCell.X > 0 || CurrentCell.Y > 0)
                {
                    _isReturning = true;
                    if (CurrentDirection == Direction.West)
                    {
                        CurrentCell.X -= 1;
                        if (CurrentCell.X == 0)
                        {
                            CurrentDirection = Direction.North;
                        }                        
                    }
                    else if(CurrentDirection == Direction.North)
                    {
                        CurrentCell.Y -= 1;                       
                    }
                    else if(CurrentDirection == Direction.East)
                    {
                        CurrentCell.X -= 1;
                        CurrentDirection = Direction.West;
                    }

                    DrawPath(CurrentCell);
                }
                else
                {
                    var timer = sender as DispatcherTimer;
                    if (timer != null)
                    {
                        timer.Stop();

                        App.Current.Dispatcher.Invoke(new Action(() =>
                        {
                            MessageBox.Show("Done!");
                        }));

                        _isCleaningRun = false;
                        Initialize();
                        // need to send message to drawing canvas to clean canvas and remove all elements. 
                    }
                }

            }
            catch (Exception ex)
            {
                App.Current.Dispatcher.Invoke(new Action(() =>
                {
                    MessageBox.Show(ex.Message);
                }));
            }
        }

        /// <summary>
        /// Draw path on cell which is cleaned by robot
        /// </summary>
        /// <param name="currentposition"></param>
        private void DrawPath(Cell currentposition)
        {
            try
            {
                Element newElement = new Element
                {
                    X = (int)currentposition.X,
                    Y = (int)currentposition.Y
                };

               var cell = Cells.Where(i => i.X == currentposition.X && i.Y == currentposition.Y).FirstOrDefault();

                if (cell != null && (!cell.IsClean || _isReturning))
                {
                    if(_isReturning)
                    {
                        newElement.Type = ElementType.ReturnPath;
                    }
                    Elements.Add(newElement);
                    cell.IsClean = true;
                }
            }
            catch (Exception ex)
            {
                App.Current.Dispatcher.Invoke(new Action(() =>
                {
                    MessageBox.Show(ex.Message);
                }));

            }
        }


        #endregion
    }
}
